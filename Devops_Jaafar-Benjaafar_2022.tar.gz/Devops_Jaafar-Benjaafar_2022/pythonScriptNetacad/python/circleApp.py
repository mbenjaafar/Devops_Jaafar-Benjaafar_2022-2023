from circleModule import Circle

cirle1 = Circle(2)
cirle1.printCircumference()

cirle2 = Circle(5)
cirle2.printCircumference()

cirle3 = Circle(7)
cirle3.printCircumference()