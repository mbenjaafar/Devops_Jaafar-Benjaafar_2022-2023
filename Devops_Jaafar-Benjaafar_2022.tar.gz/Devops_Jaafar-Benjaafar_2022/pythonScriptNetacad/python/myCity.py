def myCity(city):
    print("I live in " + city + "." )

myCity("Minsk")
myCity("Brussel")
myCity("Moskou")