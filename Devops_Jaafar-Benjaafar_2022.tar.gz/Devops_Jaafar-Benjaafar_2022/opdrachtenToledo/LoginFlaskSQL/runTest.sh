#!/bin/bash

echo "python3 flask_app_test.py"
